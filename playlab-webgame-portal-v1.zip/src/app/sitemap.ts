import type { MetadataRoute } from "next";
import { games } from "@/data/games";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://your-domain.example";
  return [
    { url: base, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/about`, changeFrequency: "monthly", priority: 0.4 },
    { url: `${base}/privacy`, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/terms`, changeFrequency: "yearly", priority: 0.2 },
    { url: `${base}/licensing`, changeFrequency: "monthly", priority: 0.3 },
    ...games.map(g => ({ url: `${base}/games/${g.slug}`, changeFrequency: "weekly" as const, priority: 0.7 }))
  ];
}
