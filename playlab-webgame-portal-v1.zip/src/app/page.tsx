"use client";
import { useMemo, useState } from "react";
import GameCard from "@/components/GameCard";
import AdSlot from "@/components/AdSlot";
import { categories, games } from "@/data/games";

export default function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("전체");
  const filtered = useMemo(() => games.filter(g =>
    (category === "전체" || g.category === category) &&
    `${g.title} ${g.category} ${g.description}`.toLowerCase().includes(query.toLowerCase())
  ), [query, category]);
  return <main className="container">
    <section className="hero">
      <div><div className="eyebrow">YOUR NEXT MINI ESCAPE</div>
        <h1>잠깐의 여유를<br/><span className="gradient">플레이로 채우다.</span></h1>
        <p>설치도 가입도 필요 없이, 브라우저에서 가볍게 즐기는 게임 공간. 마음에 드는 게임을 찾아 바로 시작해 보세요.</p>
        <div className="hero-actions"><a className="btn" href="#games">게임 둘러보기 <span>↗</span></a><a className="btn secondary" href="/about">플레이랩 소개</a></div>
      </div>
      <div className="hero-art" aria-hidden="true"><div className="arcade-screen"><div className="screen-label">PRESS START</div><div className="pixel-star">✦</div><div style={{ color: "#b7bdd4", fontSize: 11, letterSpacing: 2 }}>PLAY · EXPLORE · REPEAT</div></div></div>
    </section>
    <section className="stats" aria-label="사이트 특징">
      <div className="stat"><strong>01</strong><span>직접 제작한 플레이 게임</span></div>
      <div className="stat"><strong>0원</strong><span>무료로 시작하는 플레이</span></div>
      <div className="stat"><strong>100%</strong><span>브라우저 기반</span></div>
    </section>
    <AdSlot label="광고 영역 · 상단" />
    <section id="games">
      <div className="section-head"><div><div className="eyebrow">GAME LIBRARY</div><h2>오늘은 어떤 게임?</h2><p>취향에 맞는 게임을 검색하고 골라보세요.</p></div></div>
      <div className="tools">
        <label className="search"><span aria-hidden="true">⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="게임 이름이나 장르 검색..." aria-label="게임 검색" /></label>
      </div>
      <div id="categories" className="tools" aria-label="카테고리 필터">{categories.map(c => <button key={c} className={`filter ${category === c ? "active" : ""}`} onClick={() => setCategory(c)}>{c}</button>)}</div>
      <div className="game-grid">{filtered.length ? filtered.map(game => <GameCard key={game.slug} game={game} />) : <div className="empty">검색 결과가 없어요. 다른 키워드로 찾아보세요.</div>}</div>
    </section>
    <AdSlot label="광고 영역 · 게임 목록 하단" />
    <section style={{ padding: "20px 0 10px" }}><div className="section-head"><div><div className="eyebrow">BUILT WITH CARE</div><h2>게임은 재미있게, 권리는 명확하게.</h2><p>게임별 라이선스를 확인하고, 안전하고 투명한 게임 공간을 지향합니다.</p></div><a className="btn secondary" href="/licensing">라이선스 정책 ↗</a></div></section>
  </main>;
}
