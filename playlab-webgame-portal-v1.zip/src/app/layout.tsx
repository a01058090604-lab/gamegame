import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://your-domain.example";
export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "플레이랩 — 가볍게 즐기는 웹게임", template: "%s | 플레이랩" },
  description: "브라우저에서 바로 즐기는 캐주얼 웹게임. 액션, 퍼즐, 레이싱 게임을 찾아보세요.",
  applicationName: "플레이랩",
  openGraph: { type: "website", locale: "ko_KR", siteName: "플레이랩", title: "플레이랩 — 가볍게 즐기는 웹게임", description: "브라우저에서 바로 즐기는 캐주얼 웹게임." },
  robots: { index: true, follow: true }
};

function Header() {
  return <header className="topbar"><div className="container nav">
    <Link href="/" className="brand"><span className="brand-mark">✦</span> 플레이랩</Link>
    <nav className="navlinks" aria-label="주요 메뉴"><a href="/#games">게임 탐색</a><a href="/#categories">카테고리</a><Link href="/about">소개</Link></nav>
    <span className="nav-spacer" />
    <span className="status">✦ 무료 플레이 · 브라우저에서 바로</span>
    <a className="mobile-menu" href="/#games">게임 찾기 ↓</a>
  </div></header>;
}
function Footer() {
  return <footer className="footer"><div className="container footer-inner">
    <Link href="/" className="brand"><span className="brand-mark">✦</span> 플레이랩</Link>
    <nav className="footer-links" aria-label="정책 링크"><Link href="/about">사이트 소개</Link><Link href="/privacy">개인정보처리방침</Link><Link href="/terms">이용약관</Link><Link href="/licensing">저작권·라이선스</Link></nav>
    <span className="footer-copy">© {new Date().getFullYear()} PlayLab. Built for play.</span>
  </div></footer>;
}
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ko"><body><Header />{children}<Footer /></body></html>;
}
