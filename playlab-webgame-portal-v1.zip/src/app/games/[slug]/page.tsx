import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { games } from "@/data/games";
import AdSlot from "@/components/AdSlot";
import StarDashGame from "@/components/StarDashGame";

export function generateStaticParams() { return games.map(game => ({ slug: game.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params; const game = games.find(g => g.slug === slug);
  if (!game) return { title: "게임을 찾을 수 없습니다" };
  return { title: `${game.title} - 무료 웹게임`, description: game.description, openGraph: { title: `${game.title} | 플레이랩`, description: game.description, type: "website" } };
}
export default async function GamePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const game = games.find(g => g.slug === slug);
  if (!game) notFound();
  const playable = game.slug === "star-dash";
  return <main className="container page" style={{ maxWidth: 1160 }}>
    <div className="breadcrumbs"><Link href="/">홈</Link> / <Link href="/#games">게임</Link> / {game.title}</div>
    <div className="section-head"><div><div className="eyebrow">{game.category.toUpperCase()} · {game.players.toUpperCase()}</div><h1 style={{ margin: "8px 0" }}>{game.emoji} {game.title}</h1><p>{game.description}</p></div><Link className="btn secondary" href="/#games">← 게임 목록</Link></div>
    <AdSlot label="광고 영역 · 게임 위" />
    {playable ? <div className="game-layout"><div><StarDashGame /><div className="notice">이 게임은 이 프로젝트를 위해 직접 제작한 HTML5 게임입니다. 외부 게임 배포물을 가져오지 않았습니다.</div></div><aside className="side-panel"><h3>🎮 플레이 방법</h3><p>{game.instructions}</p><h3 style={{ marginTop: 22 }}>게임 정보</h3><p>장르: {game.category}<br/>플레이: {game.players}<br/>권리 상태: {game.licenseLabel}</p><p>최고 기록은 현재 페이지 세션에서만 유지됩니다.</p></aside></div> : <div className="notice"><strong>게임 준비 중</strong><br/>이 항목은 포털 검색·분류 UI를 보여주기 위한 카탈로그 샘플입니다. 실제 게임 파일과 재배포 권한을 확인하기 전에는 플레이를 제공하지 않습니다. <Link href="/licensing">라이선스 안내 보기</Link></div>}
    <AdSlot label="광고 영역 · 게임 아래" />
  </main>;
}
