import Link from "next/link";
export default function NotFound() { return <main className="container not-found"><div className="eyebrow">404 · GAME NOT FOUND</div><h1>앗, 게임을 찾을 수 없어요.</h1><p style={{ color: "#a3abc3" }}>주소를 확인하거나 게임 목록으로 돌아가 보세요.</p><Link className="btn" href="/">홈으로 돌아가기</Link></main>; }
