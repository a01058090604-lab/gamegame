export type Game = {
  slug: string; title: string; category: string; description: string;
  emoji: string; cover: string; badge: string; players: string;
  instructions: string; licenseLabel: string;
};
export const games: Game[] = [
  { slug: "star-dash", title: "스타 대시", category: "액션", description: "반짝이는 별을 모으고 장애물을 피해 최고 기록에 도전하세요.", emoji: "🌠", cover: "cover-purple", badge: "직접 제작", players: "1인", instructions: "화면을 탭하거나 스페이스바를 눌러 점프하세요. 장애물을 피하면서 별을 모으세요.", licenseLabel: "자체 제작" },
  { slug: "color-orbit", title: "컬러 오빗", category: "캐주얼", description: "색을 맞추며 반응 속도를 시험하는 가벼운 아케이드 게임.", emoji: "🪐", cover: "cover-cyan", badge: "캐주얼", players: "1인", instructions: "첫 버전에서는 게임 포털 구조 데모로 제공됩니다. 게임 콘텐츠는 자체 제작 게임부터 순차적으로 추가하세요.", licenseLabel: "콘텐츠 준비 중" },
  { slug: "puzzle-pop", title: "퍼즐 팝", category: "퍼즐", description: "잠깐의 휴식에 어울리는 두뇌 게임 컬렉션이 준비 중입니다.", emoji: "🧩", cover: "cover-pink", badge: "퍼즐", players: "1인", instructions: "이 항목은 카탈로그 UI 확인용입니다. 실제 게임을 등록하기 전까지 플레이를 제공하지 않습니다.", licenseLabel: "콘텐츠 준비 중" },
  { slug: "pixel-rally", title: "픽셀 랠리", category: "레이싱", description: "픽셀 감성의 스피드 게임을 만나보세요. 레이싱 콘텐츠 준비 중.", emoji: "🏎️", cover: "cover-orange", badge: "레이싱", players: "1인", instructions: "이 항목은 카탈로그 UI 확인용입니다. 실제 게임을 등록하기 전까지 플레이를 제공하지 않습니다.", licenseLabel: "콘텐츠 준비 중" },
  { slug: "tiny-garden", title: "타이니 가든", category: "캐주얼", description: "아기자기한 정원 테마의 편안한 게임을 준비하고 있어요.", emoji: "🌱", cover: "cover-cyan", badge: "힐링", players: "1인", instructions: "이 항목은 카탈로그 UI 확인용입니다. 실제 게임을 등록하기 전까지 플레이를 제공하지 않습니다.", licenseLabel: "콘텐츠 준비 중" },
  { slug: "neon-blocks", title: "네온 블록", category: "퍼즐", description: "간결한 규칙과 선명한 네온 그래픽의 퍼즐 게임 예정.", emoji: "🔷", cover: "cover-purple", badge: "퍼즐", players: "1인", instructions: "이 항목은 카탈로그 UI 확인용입니다. 실제 게임을 등록하기 전까지 플레이를 제공하지 않습니다.", licenseLabel: "콘텐츠 준비 중" }
];
export const categories = ["전체", "액션", "캐주얼", "퍼즐", "레이싱"];
