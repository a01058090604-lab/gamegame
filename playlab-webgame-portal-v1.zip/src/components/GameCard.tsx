import Link from "next/link";
import type { Game } from "@/data/games";
export default function GameCard({ game }: { game: Game }) {
  const playable = game.slug === "star-dash";
  return <article className="game-card">
    <Link href={`/games/${game.slug}`} aria-label={`${game.title} ${playable ? "플레이하기" : "상세 보기"}`}>
      <div className={`game-cover ${game.cover}`}>
        <span className="game-badge">{game.badge}</span>
        <span className="emoji" aria-hidden="true">{game.emoji}</span>
      </div>
    </Link>
    <div className="game-body">
      <h3 className="game-title"><Link href={`/games/${game.slug}`}>{game.title}</Link></h3>
      <p className="game-desc">{game.description}</p>
      <div className="game-meta"><span className="tag">{game.category}</span><Link className="play-link" href={`/games/${game.slug}`}>{playable ? "지금 플레이 ↗" : "살펴보기 ↗"}</Link></div>
    </div>
  </article>;
}
