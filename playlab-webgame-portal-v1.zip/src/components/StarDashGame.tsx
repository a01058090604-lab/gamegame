"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export default function StarDashGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);
  const stateRef = useRef({ running: false, y: 340, vy: 0, obstacleX: 850, score: 0, best: 0, last: 0, over: false });
  const [status, setStatus] = useState("시작 버튼을 눌러 플레이하세요");
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);

  const jump = useCallback(() => {
    const s = stateRef.current;
    if (!s.running) return;
    if (s.y >= 335) s.vy = -500;
  }, []);

  const start = useCallback(() => {
    const s = stateRef.current;
    s.running = true; s.y = 340; s.vy = 0; s.obstacleX = 850; s.score = 0; s.last = 0; s.over = false;
    setScore(0); setStatus("별을 모으고 장애물을 피하세요!");
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    let alive = true;
    const draw = (time: number) => {
      if (!alive) return;
      const s = stateRef.current;
      const dt = s.last ? Math.min((time - s.last) / 1000, 0.035) : 0;
      s.last = time;
      const w = 800, h = 460;
      ctx.clearRect(0, 0, w, h);
      const bg = ctx.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, "#141c38"); bg.addColorStop(1, "#202447");
      ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
      // Stars in the sky
      for (let i = 0; i < 42; i++) {
        const x = (i * 137 + 19) % w, y = (i * 71 + 17) % 280;
        ctx.fillStyle = i % 4 === 0 ? "#9dece1" : "#c6c5ff";
        ctx.globalAlpha = 0.35 + (i % 5) * 0.12; ctx.fillRect(x, y, i % 3 + 1, i % 3 + 1);
      }
      ctx.globalAlpha = 1;
      // Ground
      ctx.fillStyle = "#31365b"; ctx.fillRect(0, 380, w, 80);
      ctx.fillStyle = "#70e4d3"; ctx.fillRect(0, 380, w, 4);
      for (let x = -((time / 8) % 48); x < w; x += 48) { ctx.fillStyle = "#474d77"; ctx.fillRect(x, 405, 24, 3); }
      if (s.running) {
        s.vy += 1300 * dt; s.y += s.vy * dt;
        if (s.y > 340) { s.y = 340; s.vy = 0; }
        s.obstacleX -= 280 * dt;
        if (s.obstacleX < -40) { s.obstacleX = 830 + Math.random() * 220; s.score += 1; setScore(s.score); }
        if (s.obstacleX < 112 && s.obstacleX > 50 && s.y > 300) {
          s.running = false; s.over = true; s.best = Math.max(s.best, s.score); setBest(s.best);
          setStatus(`게임 종료! ${s.score}점을 기록했어요. 다시 도전해 보세요.`);
        }
      }
      // Obstacle
      ctx.fillStyle = "#ff8eb6"; ctx.beginPath(); ctx.roundRect(s.obstacleX, 344, 28, 36, 7); ctx.fill();
      ctx.fillStyle = "#ffc1d8"; ctx.fillRect(s.obstacleX + 6, 350, 5, 12);
      // Player
      ctx.fillStyle = "#a99cff"; ctx.beginPath(); ctx.roundRect(70, s.y, 42, 40, 10); ctx.fill();
      ctx.fillStyle = "#f5f2ff"; ctx.fillRect(82, s.y + 10, 6, 7); ctx.fillRect(98, s.y + 10, 6, 7);
      ctx.fillStyle = "#292244"; ctx.fillRect(85, s.y + 26, 16, 4);
      // Collectible star
      const sx = 410, sy = 285 + Math.sin(time / 260) * 12;
      ctx.fillStyle = "#ffe69b"; ctx.font = "28px sans-serif"; ctx.fillText("✦", sx, sy);
      if (!s.running) {
        ctx.fillStyle = "#080b13aa"; ctx.fillRect(0, 0, w, h);
        ctx.textAlign = "center"; ctx.fillStyle = "#f4f6ff"; ctx.font = "bold 32px sans-serif";
        ctx.fillText(s.over ? "TRY AGAIN" : "STAR DASH", w / 2, 195);
        ctx.fillStyle = "#b8c0db"; ctx.font = "16px sans-serif";
        ctx.fillText(s.over ? `기록 ${s.score}점 · 아래에서 다시 시작` : "점프해서 장애물을 피하세요", w / 2, 230);
        ctx.textAlign = "start";
      }
      frameRef.current = requestAnimationFrame(draw);
    };
    frameRef.current = requestAnimationFrame(draw);
    const onKey = (e: KeyboardEvent) => { if (e.code === "Space" || e.code === "ArrowUp") { e.preventDefault(); jump(); } };
    window.addEventListener("keydown", onKey);
    return () => { alive = false; cancelAnimationFrame(frameRef.current); window.removeEventListener("keydown", onKey); };
  }, [jump]);

  return <div className="game-stage">
    <canvas ref={canvasRef} width={800} height={460} onPointerDown={jump} role="img" aria-label="스타 대시 게임 화면. 탭 또는 스페이스바로 점프합니다." />
    <div className="game-controls">
      <span>{status}</span>
      <span>점수 <strong>{score}</strong> · 최고 <strong>{best}</strong></span>
      <button className="btn" onClick={start}>{stateRef.current.over ? "다시 플레이" : "게임 시작"}</button>
    </div>
    <p style={{ color: "#a3abc3", fontSize: 12, lineHeight: 1.7, margin: "12px 2px 2px" }}>조작: 스페이스바 / ↑ / 게임 화면 탭으로 점프. 화면 크기에 맞춰 표시되며, 키보드와 터치를 지원합니다.</p>
  </div>;
}
