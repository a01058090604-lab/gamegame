type Props = { label?: string };
export default function AdSlot({ label = "광고 영역" }: Props) {
  // Deliberately no ad-network script. Integrate only after approval and policy review.
  return <aside className="ad-slot" aria-label={label}>
    <div>{label}<small>광고 승인 후 이 위치에 광고가 표시됩니다.</small></div>
  </aside>;
}
